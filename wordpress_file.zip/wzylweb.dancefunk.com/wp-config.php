<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wzylweb' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '@}T!4[E`3E.OuHlwx2v4V!HO!(3f^_;~aksIo8%AVCUEuU[y<YlH{_/rb79ArrB$' );
define( 'SECURE_AUTH_KEY',  'gr`EWYJx8WA~aXnJ1GB]nbaGKdFpLhk]Yi4KOC~LH_8pWT8p5Z$1WY#mua/?P;lq' );
define( 'LOGGED_IN_KEY',    '}Vo7ojg!L>^GaO/wiNz/My<_Oc#ow#x#WcH&tuOsP-qV>p ^w]+cLH~M,gwCEUB ' );
define( 'NONCE_KEY',        '>4OC))]h]7sf%)L+Ya`#B]J3j(s`y,QJC0N{_t]{B-]Z%/74`D6AWNlwj$QlT}sV' );
define( 'AUTH_SALT',        'wkQCbV?W6|bK|#SKE0C=jw$%SFH?UU$?7Du9mN>Vwz1+{]xiw5 2$@!og/#BgJ8Z' );
define( 'SECURE_AUTH_SALT', 'q/B6cG@[?]<2gN~s~yV{7P/JY[rH-~V@Y1Y*k)7b5Jt#CQA<gVR-neh^n=tT}e9I' );
define( 'LOGGED_IN_SALT',   '/y}kN0IwV)usQyqSj9<j4vTWb-;Hn _sJU9>)]rQ.d<9>|~5/:LwWDAo`yZQa+6>' );
define( 'NONCE_SALT',       'TRqU<~q}O6uMaM5hoN]xxKk3 hX9v.%*!$=O;e`$q~_#C`Mxq*Bk-!_W@.Z@uA~5' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wz_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
